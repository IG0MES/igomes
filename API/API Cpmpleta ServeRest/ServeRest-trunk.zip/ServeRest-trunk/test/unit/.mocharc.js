module.exports = {
  spec: ['test/unit/**/*.test.js'],
  color: true,
}
