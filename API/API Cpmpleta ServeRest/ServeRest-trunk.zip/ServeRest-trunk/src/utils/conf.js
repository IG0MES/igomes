'use strict'

const conf = {
  porta: 3000,
  tokenTimeout: 600
}

module.exports = { conf }
